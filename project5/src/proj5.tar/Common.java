


/**
 * @author E. Javier Figueroa 
 * COP5615 Spring 2011
 * University of Florida
 *
 */
public class Common {
	public static String NL = System.getProperty("line.separator");
}
