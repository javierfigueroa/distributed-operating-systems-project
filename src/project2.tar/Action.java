

public enum Action {
	read,
	write
}
